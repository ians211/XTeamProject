README

Course: cs400
Semester: Spring 2019
Project name: Practice Quiz Generator
Team Members:
1. member Ian Arthur, lecture 2, and iarthur@wisc.edu
2. member Sammy Kleedtke, lecture 2, and kleedtke@wisc.edu
3. member Andrew Frank, lecture 2, and ajfrank5@wisc.edu
4. member Nick Hayden, lecture 1, and nhayden@wisc.edu

Notes or comments to the grader:


[place any comments or notes that will help the grader here]
Be nice


